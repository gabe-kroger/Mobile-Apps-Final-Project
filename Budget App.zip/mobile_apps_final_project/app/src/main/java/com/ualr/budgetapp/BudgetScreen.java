package com.ualr.budgetapp;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ListView;

import java.util.ArrayList;
import java.util.List;

public class BudgetScreen extends MainActivity {

    public static final String EXTRA_ACCOUNT = "AccountData";
    EditText etTotalBudget;
    String totalBudget;
    String expenses;
    private ImageButton btnGoCalender;

    ListView listView;
    List list = new ArrayList();
    ArrayAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.layout_budget);
        btnGoCalender = (ImageButton) findViewById(R.id.calenderButton);

        btnGoCalender.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(BudgetScreen.this, CalenderActivity.class);
                startActivity(intent);
            }
        });

        listView = (ListView) findViewById(R.id.expensesList);

        list.add("Groceries");
        list.add("Gas");
        list.add("Electric Bill");
        list.add("Car Note");
        list.add("Water Bill");
        list.add("School Supplies");
        list.add("Internet Bill");
        list.add("Car Insurance");
        list.add("Car Maintenance");
        list.add("Phone Bill");
        list.add("TV Repair Cost");
        list.add("Car Tires");
        list.add("Kid's Field Trip");
        list.add("Items for Halloween Party");
        list.add("Kid's clothes for next semester");
        list.add("Sundries");
        list.add("Self-Indulging");
        list.add("Favor for friend");

        Intent incomingDate = getIntent();
        String date = incomingDate.getStringExtra("date");
        //theDate.setText(date);

        adapter = new ArrayAdapter(BudgetScreen.this, android.R.layout.simple_list_item_1, list);
        listView.setAdapter(adapter);
    }

/*    public void onTotalButtonClick(View view) {
        etTotalBudget = findViewById(R.id.etTotalBudget);
        //etExpenses = Expenses retrieved and added up from list.

        totalBudget = etTotalBudget.getText().toString();
        Intent intent = new Intent(this, Account.class);
        Account a = new Account(totalBudget, expenses);
        intent.putExtra(EXTRA_ACCOUNT, a);
        startActivity(intent);
    }*/
}
